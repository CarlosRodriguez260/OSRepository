#ifndef STRUCTDATE_H
#define STRUCTDATE_H

struct date{
    int day;
    int month;
    int year;
};

struct date FillDate(long second);

#endif // STRUCTDATE_H