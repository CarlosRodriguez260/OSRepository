#ifndef WORD_EXPLORER_H
#define WORD_EXPLORER_H

int WordExplorer(int argc, char *argv[]);

#endif // WORD_EXPLORER_H