FOR THE FIRST LAB EXCERCISE:
- The program "word_explorer" has to be built first inside the "word_explorer" folder
    - Inside the "word_explorer" folder, build the program with cmake on the corresponding "build" folder
    - This will create an executable program called "word_explorer", which is needed for the lab excercise

- After this is done, you can then build the "word_exec" program in the build folder inside "labexcercise"
    - The folder "labexcercise" is the folder that holds everything related to the program 
      asked to be made in the first home lab excercise
    - The executable program "word_exec" is the new program asked to be made, and 
      the code is in the "main.c" file in src