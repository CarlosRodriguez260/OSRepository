#ifndef CONTAINS_WORD_H
#define CONTAINS_WORD_H

int ContainsWord(const char *filepath, const char *word);

#endif // CONTAINS_WORD_H