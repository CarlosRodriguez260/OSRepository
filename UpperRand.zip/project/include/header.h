#ifndef UPPERRAND_H
#define UPPERRAND_H

void UpperRand(char * base, char * mod);
void PrintArray(char * base, char * mod);

#endif // UPPERRAND_H