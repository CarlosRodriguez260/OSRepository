#ifndef SCHEDULING_H
#define SCHEDULING_H

int isPrime(int n);

#endif // SCHEDULING_H