#include <math.h>
#include <pthread.h>
#include <sched.h>
#include <stdio.h>
#include <string.h>
#include <sys/resource.h>
#include <unistd.h>
#include "header.h"

// Main function used to launch the programs
int main(){
    // Determine what scheduler to use
    int mode;
    printf("1 for FCFS\n2 for FIFO/RR\n");\
    scanf("%d",&mode);

    if(mode==1){
        // Calls the FCS Scheduler program
        fcs();
    }
    else{
        // Calls the RR / FIFO Scheduler program
        rrfifo();
    }
}