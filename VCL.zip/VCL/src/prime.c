#include <math.h>

// Function for checking if number `n` is prime
int isPrime(int n){
    if (n % 2 == 0 || n % 3 == 0 || n % 5 == 0 || n % 7 == 0) return 0; 

    // Check divisibility from 11 to sqrt(n), skipping even numbers
    for (int i = 11; i * i <= n; i += 2) {
        if (n % i == 0) return 0; // Found a factor
    }

    return 1; // Prime
}