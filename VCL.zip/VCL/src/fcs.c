#include <math.h>
#include <pthread.h>
#include <sched.h>
#include <stdio.h>
#include <string.h>
#include <sys/resource.h>
#include <unistd.h>
#include "header.h"

// Global Variables
int nice1;
int nice2;
int nice3;
double time1;
double time2;
double time3;

// Thread for processing the prime numbers
void * primeThread(void * arg){
    struct timespec start, end;

    // Start calculating time of thread calculations
    clock_gettime(CLOCK_MONOTONIC, &start);

    int argument = *(int*)arg;
    if(argument==1){
        // Thread 1
        nice(nice1); // Set the nice value per thread

        // Look at primes through 200,000 -> 300,000
        for(int i = 200000; i<300000; i++){
            if(isPrime(i)==1){
                printf("[Thread 1]: Prime %d found\n", i);
            }
        }

        // Stop measuring thread time
        clock_gettime(CLOCK_MONOTONIC,&end);

        // Calculate thread time and save to global variable
        double elapsed_time = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1E9;
        time1 = elapsed_time;
    }
    else if(argument==2){
        // Thread 2
        nice(nice2); // Set the nice value per thread

        for(int i = 300000; i<400000; i++){
            if(isPrime(i)==1){
                printf("[Thread 2]: Prime %d found\n", i);
            }

        }
        clock_gettime(CLOCK_MONOTONIC,&end);
        
        double elapsed_time = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1E9;
        time2 = elapsed_time;
    }
    else if(argument==3){
        // Thread 3
        nice(nice3); // Set the nice value per thread

        for(int i = 400000; i<500000; i++){
            if(isPrime(i)==1){
                printf("[Thread 3]: Prime %d found\n", i);
            }

        }
        clock_gettime(CLOCK_MONOTONIC,&end);

        double elapsed_time = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1E9;
        time3 = elapsed_time;
    }
    else{
        // Do nothing
    }
}

int fcs(){
    // Setup thread variables and get nice values from user
    pthread_t t1, t2, t3;
    int arg1 = 1, arg2 = 2, arg3 = 3;
    printf("Enter the nice values for the 3 threads\n");
    scanf("%d",&nice1);
    scanf("%d",&nice2);
    scanf("%d",&nice3);

    pthread_attr_t attr;

    // Set default attributes and launch threads
    pthread_attr_init(&attr);
    pthread_create(&t1, &attr, primeThread, &arg1);

    pthread_attr_init(&attr);
    pthread_create(&t2, &attr, primeThread, &arg2);

    pthread_attr_init(&attr);
    pthread_create(&t3, &attr, primeThread, &arg3);

    // Wait until all threads are finished
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);

    // Print out the time it took the threads to finish
    printf("Thread 1 took %f seconds\n",time1);
    printf("Thread 2 took %f seconds\n",time2);
    printf("Thread 3 took %f seconds\n",time3);
    return 0;
}