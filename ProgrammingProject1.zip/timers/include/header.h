#ifndef TIMERS_H
#define TIMERS_H

void write_elapsed_time(double elapsed_time);

#endif // TIMERS_H