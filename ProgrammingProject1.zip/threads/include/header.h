#ifndef UPPERRAND_H
#define UPPERRAND_H

void write_elapsed_time(double elapsed_time);

#endif // UPPERRAND_H