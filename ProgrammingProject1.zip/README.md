# OSRepository
# Para la clase de Sistemas Operativos
# Brach de 'main' es la base para cada proyecto/laboratorio
  - Copia este branch a otro para cada proyecto/laboratorio
# Dependencias necesitadas:
  - CLANG & CLANG-FORMAT
  - GIT & GH
  - CMAKE
  - DOXYGEN EXTENSION (VSCODE)