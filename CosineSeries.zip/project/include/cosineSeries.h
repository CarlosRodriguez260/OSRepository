#ifndef COSINESERIES_H
#define COSINESERIES_H

int CosineSeries(int init_number, int end_number);

#endif // COSINESERIES_H