#include "cosineSeries.h"

int main() 
{
  CosineSeries(4,23); // Returns -1
  printf("\n");
  CosineSeries(1,1); // Returns 1
  return 0;
}