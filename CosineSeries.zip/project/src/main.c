#include "cosineSeries.h"

int main() 
{
  int x;
  int y;
  printf("Enter the initial and final inputs: \n");
  scanf("%d %d",&x, &y);
  CosineSeries(x,y);
  return 0;
}