#ifndef FILLDATE_H
#define FILLDATE_H

void FillDate(long second, int* day, int* month, int* year);

#endif // FILLDATE_H