#ifndef LAB5_H
#define LAB5_H

void csvCreator(float * numbers, int rows, int columns);

#endif // LAB5_H