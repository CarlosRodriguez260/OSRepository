#ifndef PRINTARRAY_H
#define PRINTARRAY_H

void PrintArray(void* array, int type);

#endif // PRINTARRAY_H